# VPN NET — proyecto Android inicial

Este proyecto contiene una primera versión visual para Android con selección de Tigo, Personal y Claro Paraguay.

## Estado importante
Esta versión **no establece una conexión VPN real** y no ofrece internet gratis. Para activar una VPN real hace falta contratar, alojar o conseguir un servidor VPN legítimo, configurar sus claves y añadir un cliente de túnel (por ejemplo, WireGuard). No se incluyen servidores ni credenciales ficticias.

## Cómo abrir
1. Instala Android Studio en una computadora.
2. Abre esta carpeta como proyecto.
3. Espera la sincronización de Gradle.
4. Conecta un teléfono Android con depuración USB o usa un emulador.
5. Pulsa Run para instalar la versión de prueba.

La compilación requiere Android SDK 35 y conexión a internet para descargar dependencias.
