package com.vpnnet.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var selected = "Tigo Paraguay"
    private lateinit var status: TextView
    private lateinit var connect: Button
    private val navy = Color.rgb(16, 27, 50)
    private val cyan = Color.rgb(40, 199, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 34, 28, 24)
            setBackgroundColor(navy)
        }

        val logo = TextView(this).apply {
            text = "🛡"
            textSize = 48f
            gravity = Gravity.CENTER
        }
        page.addView(logo, match(76))

        val title = TextView(this).apply {
            text = "VPN NET"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        page.addView(title, match(48))

        val subtitle = TextView(this).apply {
            text = "PARAGUAY  •  CONEXIÓN PRIVADA"
            textSize = 12f
            setTextColor(Color.rgb(155, 203, 255))
            gravity = Gravity.CENTER
        }
        page.addView(subtitle, match(32))

        val spacer = View(this)
        page.addView(spacer, LinearLayout.LayoutParams(1, 28))

        val choose = TextView(this).apply {
            text = "SELECCIONA TU OPERADORA"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(choose, match(40))

        listOf("Tigo Paraguay", "Personal Paraguay", "Claro Paraguay").forEach { operator ->
            val b = Button(this).apply {
                text = operator
                textSize = 15f
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = rounded(if (operator == selected) cyan else Color.rgb(37, 54, 82), 18)
                setOnClickListener {
                    selected = operator
                    refreshOperatorButtons(page)
                }
                tag = "operator"
            }
            val lp = LinearLayout.LayoutParams(-1, 54).apply { bottomMargin = 10 }
            page.addView(b, lp)
        }

        val gap = View(this)
        page.addView(gap, LinearLayout.LayoutParams(1, 20))

        status = TextView(this).apply {
            text = "Estado: desconectado"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(status, match(44))

        connect = Button(this).apply {
            text = "CONECTAR"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            setTextColor(navy)
            background = rounded(cyan, 28)
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("VPN NET")
                    .setMessage("La pantalla de VPN NET está lista, pero todavía no puede establecer una conexión real. Falta configurar un servidor VPN gratuito y sus credenciales. No se ha conectado ninguna VPN.")
                    .setPositiveButton("ENTENDIDO", null)
                    .show()
            }
        }
        page.addView(connect, LinearLayout.LayoutParams(-1, 60))

        val note = TextView(this).apply {
            text = "La conexión real requiere un servidor VPN activo. Esta versión es una base visual de la aplicación."
            textSize = 11f
            setTextColor(Color.rgb(174, 190, 211))
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 0)
        }
        page.addView(note, match(70))

        setContentView(page)
    }

    private fun refreshOperatorButtons(root: LinearLayout) {
        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            if (v is Button && v.tag == "operator") {
                val name = v.text.toString()
                v.background = rounded(if (name == selected) cyan else Color.rgb(37, 54, 82), 18)
                v.setTextColor(if (name == selected) navy else Color.WHITE)
            }
        }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun match(height: Int) = LinearLayout.LayoutParams(-1, height)
}
